


const Product = () => {
    return (
        <p>Hi from Product</p>
    )
}

export default Product;